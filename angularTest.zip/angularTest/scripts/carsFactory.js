angular
    .module("ngCars")
    .factory("carsFactory", function($http) {

          function getCars () {
              return $http.get("data/data.json");
          }

          return {
              getCars: getCars
          }
    });