angular
	.module('ngCars')
	.controller('carsController', function($scope, carsFactory) {

		$scope.cars;

		carsFactory.getCars().success(function(data) {
			$scope.cars = data;
		}).error(function(error){
			console.log(error);
		});

		$scope.sayHello = function(){
			console.log("Hello!");
		}

	});